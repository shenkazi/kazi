import os
print ("""
                                             
                             \033[95m⣿⣿⣿⠿⠿⣿⣿⡿⢋⣶⣶⣬⣙⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿
                             \033[95⣿⡿⢡⣿⣷⣶⣦⣥⣿⣿⣿⣿⣿⣷⣮⡛⢿⣿⣿⣿⣿⣿⣿⣿
                             \033[95⣿⡇⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢮⡙⣿⣿⣯⢐⡎⣿
                             \033[95⣿⢹⣿⣿⣿⣿⣿⣿⡿⣡⡬⢿⣿⣿⣿⣶⣶⣼⣦⠥⣖⣩⣾⣿
                             \033[95⣿⢸⣿⣿⣿⡿⣿⣿⣿⣿⠇⣌⢛⣻⣿⣿⣟⣛⣿⣧⠹⣿⣿⣿
                             \033[95⠏⣼⣿⣿⢏⣾⣿⣟⣩⣶⣶⣿⣿⣿⣿⣿⡟⡿⢸⡿⣡⣿⣿⣿
                             \033[95⣼⣿⣿⠇⣼⣿⣿⢸⠋⠁⠉⢽⣿⣿⣿⣟⣠⣤⣆⢃⢻⣿⣿⣿
                             \033[95⣿⣿⣿⣼⣿⣿⣿⡞⣿⣿⣷⣾⣿⣿⣿⣿⡿⠟⠛⠸⢦⣙⡋⣿
                             \033[95⣿⣿⣿⠹⣿⣿⡿⠗⣈⣭⣭⣭⣉⠻⡟⣩⣶⣾⣿⣿⣶⡙⣱⣿
                             \033[95⣿⣿⣿⣷⣌⡛⠠⣿⣿⣿⣿⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⢸⣿
                             \033[95⣿⣿⣿⣿⢏⣴⣧⣴⡘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣱⣶⣴⡜⢸⣿
                             \033[95⣿⣿⣿⢃⣾⣿⣿⣿⡷⠉⢿⣿⣿⣿⣿⣿⣿⢰⣾⣿⣿⣧⢸⣿
                          
""")
print("""\33[0;32m[1] RUN\n[2] CANCEL\nCancel or Run?""")
c = input(">>>: ")
if c == "1":
    os.system("apt upgrade")
    os.system("apt update")
    os.system("apt install npm -y")
    os.system("apt install screen -y")
    os.system("npm install gradient-string")
    os.system("npm install path")
    os.system("npm install net")
    os.system("npm install http2")
    os.system("npm install tls")
    os.system("npm install url")
    os.system("npm install crypto")
    os.system("npm install fs")
    os.system("npm install colors")
    os.system("npm install os")
    os.system("npm install http")
    os.system("npm install fake-useragent")
    os.system("npm install axios")
    os.system("npm install useragent")
    os.system("npm install minimist")
    os.system("npm install hex")
    os.system("npm install events")
    os.system("npm install cluster")
    os.system("npm install cheerio")
    os.system("npm install captcha")
    os.system("npm install cloudscraper")
    os.system("npm install request")
    os.system("npm install gradient-string")
    os.system("npm install user-agent")
    os.system("npm install path")
    os.system("npm install https")
    
elif c == "2":
    os.system("clear")
print ("DONE!")